package com.example.loginscreen

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    private lateinit var email: EditText
    private lateinit var password:EditText
    lateinit var button:Button
    private val sharedPrefFile = "myPrefernceces"
    lateinit var  prefs:SharedPreferences
    //private val sharedPreferences: SharedPreferences = this.getSharedPreferences(sharedPrefFile, Context.MODE_PRIVATE)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs=getSharedPreferences(sharedPrefFile, MODE_PRIVATE)
        setContentView(R.layout.activity_main)
        val sharedIdValue = prefs.getInt("logged",0)
        if(sharedIdValue == 1){
            val intent = Intent(this,profile_page::class.java)
            startActivity(intent)
        }else{
            button = findViewById(R.id.signUp)
            button.setOnClickListener(){
                addPreferences()
            }
        }


    }

    private fun addPreferences() {
        email = findViewById(R.id.email)
        password = findViewById(R.id.password)
        val uEmail = email.text.toString()
        val uPass = password.text.toString()
        val editor: SharedPreferences.Editor = prefs.edit()
        editor.putString("email_key",uEmail)
        editor.putString("pass_key",uPass)
        editor.putInt("logged",1)
        editor.apply()
        val intent = Intent(this,profile_page::class.java)
        startActivity(intent)
    }
}