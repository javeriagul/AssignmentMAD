package com.example.loginscreen

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class profile_page: AppCompatActivity() {
    private val sharedPrefFile = "myPrefernceces"
    lateinit var  prefs: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.profile_page)
        prefs=getSharedPreferences(sharedPrefFile, MODE_PRIVATE)
        val sharedIdValue = prefs.getString("email_key","")
        val email:TextView
        email = findViewById(R.id.email)
        email.setText(sharedIdValue)
        val btn:Button = findViewById(R.id.logout)
        btn.setOnClickListener(){
            logout()
        }

    }

    private fun logout() {
        val editor = prefs.edit()
        editor.clear()
        editor.apply()
        val intent = Intent(this,MainActivity::class.java)
        startActivity(intent)
    }
}